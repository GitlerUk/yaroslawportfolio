
        function but(){


            let name=document.getElementById('one').value
            let email=document.getElementById('two').value
            let phone=document.getElementById('three').value
            let adres=document.getElementById('four').value
            let sel=document.getElementById('five').value
            let str="Що помітили: "+sel+"Адреса: "+adres+" "+"Ім'я: "+name+" "+"Номер телефону: "+phone+" "+"Email: "+email
            

            let blob = new Blob([str], {type: "text/plain"});
            let link = document.createElement("a");
            link.setAttribute("href", URL.createObjectURL (blob));
            link.setAttribute("download", Date.now()+"");
            link.click();

            swal({
  title: "Дуже Дякуємо!",
  text: "Дякуємо за проходження анкети!",
  icon: "success",
  button: "Добре",
});




        }










        function fun1(){
            let a=document.getElementById("imgsec")
            a.src="img/ua2.png"

        }
        function fun2(){
            let a=document.getElementById("imgsec")
            a.src="img/f1.jpg"

        }
        function fun3(){
            let a=document.getElementById("imgsec")
            a.src="img/f3.jpg"
        }


        let margin=0
  let element=1
  function right1(){
   let a=document.querySelector(".container div")
   if(element>=4){
    a.style.marginLeft=margin+"%"
   }
   else{
    element++
    margin-=100
    a.style.marginLeft=margin+"%"
    a.style.transition="1s"
    document.querySelector(".number").innerText=element+"/4"
   }
  }
  function left1(){
   let a=document.querySelector(".container div")
   if(element<=1){
    a.style.marginLeft=margin+"%"
   }
   else{
    element--
    margin+=100
    a.style.marginLeft=margin+"%"
    a.style.transition="1s"
    document.querySelector(".number").innerText=element+"/4"
   }
  }




$(document).ready(function(){
  $('body').append('<a href="#" id="go-top" title="Up">&uarr;</a>');
});

$(function() {
 $.fn.scrollToTop = function() {
  $(this).hide().removeAttr("href");
  if ($(window).scrollTop() >= "250") $(this).fadeIn("slow")
  var scrollDiv = $(this);
  $(window).scroll(function() {
   if ($(window).scrollTop() <= "250") $(scrollDiv).fadeOut("slow")
   else $(scrollDiv).fadeIn("slow")
  });
  $(this).click(function() {
   $("html, body").animate({scrollTop: 0}, "slow")
  })
 }
});

$(function() {
 $("#go-top").scrollToTop();
});






    function tem(){

      let tema
            if((localStorage.getItem('id_theme'))!=undefined){
                    tema=localStorage.getItem('id_theme')
                }
            else{
                tema=1
                localStorage.setItem('id_theme', 1)
            }
        if(tema==1){ 
            
            document.getElementById("sun").src="img/sunblack.png" 
            let text=document.querySelectorAll(".color") 
            let pri=document.querySelector(".color2").style.color="#FFDD1B"
            let texch=document.querySelector(".teh")
            texch.style.color="white"
            for(let i=0; i<text.length; i++){ 
                text[i].style.color="white" 
            } 
            let blue=document.querySelectorAll(".blue")
             for(let i=0; i<blue.length; i++){ 
                blue[i].style.background="#3B8CA5" 
            } 


            let blub=document.querySelector(".blubody")
            blub.style.background="#00536D"

            let blub2=document.querySelector(".blulogo")
            blub2.style.background="#00536D"

            let blub3=document.querySelector(".bluhead")
            blub3.style.background="#00536D"

            let blub4=document.querySelector(".bluchogo")
            blub4.style.background="#00536D"


           
           

            localStorage.setItem('id_theme',2)
        } 
        else if(tema==2){

            document.getElementById("sun").src="img/sunwhite.png" 
            let text=document.querySelectorAll(".color") 
            let pri=document.querySelector(".color2").style.color="#224F41"
            let texch=document.querySelector(".teh")
            texch.style.color="#1C1C1C"
            for(let i=0; i<text.length; i++){ 
                text[i].style.color="black" 
            } 

            let blue=document.querySelectorAll(".blue")
             for(let i=0; i<blue.length; i++){ 
                blue[i].style.background="#F5F5F5" 
            }

            let blub=document.querySelector(".blubody")
            blub.style.background="white"

            let blub2=document.querySelector(".blulogo")
            blub2.style.background="white"

            let blub3=document.querySelector(".bluhead")
            blub3.style.background="#3B8CA5"

            let blub4=document.querySelector(".bluchogo")
            blub4.style.background="#F5F5F5"
           


            localStorage.setItem('id_theme',1)
        } 



    }


    window.addEventListener('load', () => {
          

            let tema
            if((localStorage.getItem('id_theme'))!=0){
                    tema=localStorage.getItem('id_theme')
                }
            else{
                tema=1
                    localStorage.setItem('id_theme', tema)
            }
            if(tema==1){

            document.getElementById("sun").src="img/sunwhite.png" 
            let text=document.querySelectorAll(".color") 
            let pri=document.querySelector(".color2").style.color="#224F41"
            let texch=document.querySelector(".teh")
            texch.style.color="#1C1C1C"
            for(let i=0; i<text.length; i++){ 
                text[i].style.color="black" 
            } 

            let blue=document.querySelectorAll(".blue")
             for(let i=0; i<blue.length; i++){ 
                blue[i].style.background="#F5F5F5" 
            }

            let blub=document.querySelector(".blubody")
            blub.style.background="white"

            let blub2=document.querySelector(".blulogo")
            blub2.style.background="white"

            let blub3=document.querySelector(".bluhead")
            blub3.style.background="#3B8CA5"

            let blub4=document.querySelector(".bluchogo")
            blub4.style.background="#F5F5F5"
           

            localStorage.setItem('id_theme',1)

            
                
            }
           else if(tema==2){

            document.getElementById("sun").src="img/sunblack.png" 
            let text=document.querySelectorAll(".color") 
            let pri=document.querySelector(".color2").style.color="#FFDD1B"
            let texch=document.querySelector(".teh")
            texch.style.color="white"
            for(let i=0; i<text.length; i++){ 
                text[i].style.color="white" 
            } 
            let blue=document.querySelectorAll(".blue")
             for(let i=0; i<blue.length; i++){ 
                blue[i].style.background="#3B8CA5" 
            } 


            let blub=document.querySelector(".blubody")
            blub.style.background="#00536D"

            let blub2=document.querySelector(".blulogo")
            blub2.style.background="#00536D"

            let blub3=document.querySelector(".bluhead")
            blub3.style.background="#00536D"

            let blub4=document.querySelector(".bluchogo")
            blub4.style.background="#00536D"


            localStorage.setItem('id_theme',2)
           
            
                
            }
    });

